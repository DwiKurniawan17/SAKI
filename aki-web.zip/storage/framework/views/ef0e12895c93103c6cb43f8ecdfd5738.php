<!DOCTYPE html>
<html lang="id" class="scroll-smooth">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="description" content="Simulasi & Evaluasi Kelayakan Investasi AKI/CAPEX — Telkom Indonesia">

    <title><?php echo e($title ?? 'Simulasi AKI/CAPEX'); ?> — Telkom Indonesia</title>

    <!-- Inter Font from Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

    <!-- Lucide Icons -->
    <script src="https://unpkg.com/lucide@latest"></script>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>


    <style>[x-cloak] { display: none !important; }</style>
</head>
<body class="bg-slate-50 font-sans text-slate-800 antialiased" x-data="{ sidebarOpen: window.innerWidth >= 1024 }" @resize.window="sidebarOpen = window.innerWidth >= 1024">

<div class="flex h-screen overflow-hidden relative">

    
    <div x-show="sidebarOpen" @click="sidebarOpen = false" class="fixed inset-0 bg-slate-900/50 z-40 lg:hidden" x-transition.opacity x-cloak></div>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->guard()->check()): ?>
    <aside class="fixed inset-y-0 left-0 z-50 w-64 bg-gradient-to-b from-red-600 via-red-700 to-red-800 text-white flex flex-col transition-transform duration-300 lg:static lg:translate-x-0 border-r border-red-800/80 select-none shrink-0"
           :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full'">

        
        <div class="p-4 border-b border-red-800/80">
            <a href="<?php echo e(route('dashboard')); ?>" class="flex items-center gap-2.5 group">
                <div class="w-8 h-8 bg-white text-red-600 rounded-lg flex items-center justify-center shrink-0 shadow-xs group-hover:scale-105 transition-transform">
                    <svg class="w-4 h-4 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M13 10V3L4 14h7v7l9-11h-7z" />
                    </svg>
                </div>
                <div class="flex flex-col leading-none">
                    <span class="text-white text-sm font-black tracking-tight">Telkom<span class="text-red-200">Indonesia</span></span>
                    <span class="text-red-100 text-[10px] font-semibold tracking-wider uppercase mt-0.5">AKI / CAPEX Engine</span>
                </div>
            </a>

            
            <a href="<?php echo e(route('profile.security')); ?>" class="mt-3 block bg-red-800/80 hover:bg-red-800 border border-red-500/50 rounded-lg p-2.5 transition-colors">
                <div class="flex items-center gap-2.5">
                    <div class="w-8 h-8 rounded-lg bg-white/20 text-white flex items-center justify-center shrink-0 text-xs font-bold ring-1 ring-white/30">
                        <?php echo e(strtoupper(substr(auth()->user()->name, 0, 1))); ?>

                    </div>
                    <div class="min-w-0 flex-1">
                        <p class="text-white text-xs font-bold truncate leading-tight"><?php echo e(auth()->user()->name); ?></p>
                        <p class="text-red-100 text-[11px] font-medium truncate leading-tight mt-0.5"><?php echo e(auth()->user()->role_display_name); ?></p>
                    </div>
                </div>
            </a>
        </div>

        
        <nav class="flex-1 p-3 space-y-1 overflow-y-auto">
            <p class="px-2.5 pt-2 pb-1 text-[10px] font-bold text-red-200 uppercase tracking-wider">Menu Utama</p>

            
            <?php $active = request()->routeIs('dashboard'); ?>
            <a href="<?php echo e(route('dashboard')); ?>"
               class="flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium transition-colors <?php echo e($active ? 'bg-white text-red-700 font-bold shadow-xs' : 'text-red-100 hover:text-white hover:bg-red-800/60'); ?>">
                <i data-lucide="layout-dashboard" class="w-4 h-4 shrink-0"></i>
                <span>Dashboard</span>
            </a>

            
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->user()->hasAnyRole(['sales_marketing', 'engineering_capex'])): ?>
            <?php $active = request()->routeIs('simulasi.create'); ?>
            <a href="<?php echo e(route('simulasi.create')); ?>"
               class="flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium transition-colors <?php echo e($active ? 'bg-white text-red-700 font-bold shadow-xs' : 'text-red-100 hover:text-white hover:bg-red-800/60'); ?>">
                <i data-lucide="plus-circle" class="w-4 h-4 shrink-0"></i>
                <span>Buat Simulasi</span>
            </a>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            
            <?php $active = request()->routeIs('simulasi.riwayat') && !request('status'); ?>
            <a href="<?php echo e(route('simulasi.riwayat')); ?>"
               class="flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium transition-colors <?php echo e($active ? 'bg-white text-red-700 font-bold shadow-xs' : 'text-red-100 hover:text-white hover:bg-red-800/60'); ?>">
                <i data-lucide="history" class="w-4 h-4 shrink-0"></i>
                <span>Riwayat Simulasi</span>
            </a>

            
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->user()->hasRole('admin')): ?>
            <p class="px-2.5 pt-4 pb-1 text-[10px] font-bold text-red-200 uppercase tracking-wider">Administrator</p>

            
            <?php
                $active = request()->routeIs('simulasi.riwayat') && request('status') === 'menunggu_review';
                $pendingCount = \App\Models\SimulasiAki::where('status', 'menunggu_review')->count();
            ?>
            <a href="<?php echo e(route('simulasi.riwayat', ['status' => 'menunggu_review'])); ?>"
               class="flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-colors <?php echo e($active ? 'bg-white text-red-700 font-bold shadow-xs' : 'text-red-100 hover:text-white hover:bg-red-800/60'); ?>">
                <div class="flex items-center gap-2.5">
                    <i data-lucide="clipboard-check" class="w-4 h-4 shrink-0"></i>
                    <span>Review Simulasi</span>
                </div>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($pendingCount > 0): ?>
                <span class="<?php echo e($active ? 'bg-red-700 text-white' : 'bg-white text-red-700'); ?> text-[10px] font-bold px-1.5 py-0.5 rounded-full shadow-xs"><?php echo e($pendingCount); ?></span>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </a>

            
            <?php $active = request()->routeIs('admin.users'); ?>
            <a href="<?php echo e(route('admin.users')); ?>"
               class="flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium transition-colors <?php echo e($active ? 'bg-white text-red-700 font-bold shadow-xs' : 'text-red-100 hover:text-white hover:bg-red-800/60'); ?>">
                <i data-lucide="users" class="w-4 h-4 shrink-0"></i>
                <span>Kelola Pengguna</span>
            </a>

            
            <?php $active = request()->routeIs('admin.audit-log'); ?>
            <a href="<?php echo e(route('admin.audit-log')); ?>"
               class="flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium transition-colors <?php echo e($active ? 'bg-white text-red-700 font-bold shadow-xs' : 'text-red-100 hover:text-white hover:bg-red-800/60'); ?>">
                <i data-lucide="scroll-text" class="w-4 h-4 shrink-0"></i>
                <span>Audit Log</span>
            </a>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </nav>

        
        <div class="p-3 border-t border-red-800/80 space-y-1">
            <a href="<?php echo e(route('profile.security')); ?>"
               class="flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium transition-colors <?php echo e(request()->routeIs('profile.*') ? 'bg-white text-red-700 font-bold shadow-xs' : 'text-red-100 hover:text-white hover:bg-red-800/60'); ?>">
                <i data-lucide="settings" class="w-4 h-4 shrink-0"></i>
                <span>Pengaturan Akun</span>
            </a>
            <form method="POST" action="<?php echo e(route('logout')); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit"
                        class="flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium text-red-100 hover:text-white hover:bg-red-800/60 w-full transition-colors cursor-pointer">
                    <i data-lucide="log-out" class="w-4 h-4 shrink-0"></i>
                    <span>Keluar</span>
                </button>
            </form>
        </div>
    </aside>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <div class="flex-1 flex flex-col min-w-0 overflow-hidden">

        
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->guard()->check()): ?>
        <header class="bg-white border-b border-slate-200 h-14 flex items-center justify-between px-6 shrink-0">
            <div class="flex items-center gap-3">
                <button @click="sidebarOpen = !sidebarOpen" class="text-slate-500 hover:text-slate-700 p-1 rounded-lg transition-colors cursor-pointer" title="Toggle Sidebar">
                    <i data-lucide="menu" class="w-5 h-5"></i>
                </button>
                <div class="hidden md:flex items-center gap-2 text-xs text-slate-500 font-medium">
                    <span>Sistem Informasi Simulasi AKI / CAPEX</span>
                    <span>&bull;</span>
                    <span class="text-slate-700 font-semibold">PT Telkom Indonesia</span>
                </div>
            </div>

            <div class="flex items-center gap-3">
                <div class="flex items-center gap-2.5 pl-3 border-l border-slate-200">
                    <div class="w-7 h-7 rounded-lg bg-red-50 text-red-700 border border-red-200 flex items-center justify-center text-xs font-bold shrink-0">
                        <?php echo e(strtoupper(substr(auth()->user()->name, 0, 1))); ?>

                    </div>
                    <div class="hidden sm:block text-left">
                        <span class="text-xs font-semibold text-slate-800 block leading-tight"><?php echo e(auth()->user()->name); ?></span>
                        <span class="text-[10px] text-slate-400 block leading-tight"><?php echo e(auth()->user()->role_display_name); ?></span>
                    </div>
                </div>
                <form method="POST" action="<?php echo e(route('logout')); ?>" class="ml-1">
                    <?php echo csrf_field(); ?>
                    <button type="submit"
                            class="inline-flex items-center gap-1 text-xs text-slate-500 hover:text-red-600 hover:bg-red-50 px-2.5 py-1.5 rounded-lg border border-slate-200 transition-colors cursor-pointer"
                            title="Keluar dari sistem">
                        <i data-lucide="log-out" class="w-3.5 h-3.5"></i>
                        <span class="hidden sm:inline">Logout</span>
                    </button>
                </form>
            </div>
        </header>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>


        
        <main class="flex-1 overflow-y-auto p-4 sm:p-6 md:p-8">
            
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('status')): ?>
            <div class="mb-4" x-data="{ show: true }" x-show="show" x-transition>
                <div class="bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-lg px-4 py-3 flex items-center justify-between text-xs font-medium">
                    <div class="flex items-center gap-2">
                        <i data-lucide="check-circle-2" class="w-4 h-4 text-emerald-600 shrink-0"></i>
                        <span><?php echo e(session('status')); ?></span>
                    </div>
                    <button @click="show = false" class="text-emerald-600 hover:text-emerald-800 ml-3">&times;</button>
                </div>
            </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
            <div class="mb-4" x-data="{ show: true }" x-show="show" x-transition>
                <div class="bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-lg px-4 py-3 flex items-center justify-between text-xs font-medium">
                    <div class="flex items-center gap-2">
                        <i data-lucide="check-circle-2" class="w-4 h-4 text-emerald-600 shrink-0"></i>
                        <span><?php echo e(session('success')); ?></span>
                    </div>
                    <button @click="show = false" class="text-emerald-600 hover:text-emerald-800 ml-3">&times;</button>
                </div>
            </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('error')): ?>
            <div class="mb-4" x-data="{ show: true }" x-show="show" x-transition>
                <div class="bg-red-50 border border-red-200 text-red-800 rounded-lg px-4 py-3 flex items-center justify-between text-xs font-medium">
                    <div class="flex items-center gap-2">
                        <i data-lucide="alert-triangle" class="w-4 h-4 text-red-600 shrink-0"></i>
                        <span><?php echo e(session('error')); ?></span>
                    </div>
                    <button @click="show = false" class="text-red-600 hover:text-red-800 ml-3">&times;</button>
                </div>
            </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('warning')): ?>
            <div class="mb-4" x-data="{ show: true }" x-show="show" x-transition>
                <div class="bg-amber-50 border border-amber-200 text-amber-800 rounded-lg px-4 py-3 flex items-center justify-between text-xs font-medium">
                    <div class="flex items-center gap-2">
                        <i data-lucide="alert-circle" class="w-4 h-4 text-amber-600 shrink-0"></i>
                        <span><?php echo e(session('warning')); ?></span>
                    </div>
                    <button @click="show = false" class="text-amber-600 hover:text-amber-800 ml-3">&times;</button>
                </div>
            </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($errors->any()): ?>
            <div class="mb-4 bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded-lg text-xs">
                <div class="flex items-center gap-2 font-semibold mb-1">
                    <i data-lucide="alert-triangle" class="w-4 h-4 text-red-600 shrink-0"></i>
                    <span>Terdapat kesalahan validasi:</span>
                </div>
                <ul class="list-disc list-inside space-y-0.5 pl-6">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <li><?php echo e($error); ?></li>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </ul>
            </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php echo e($slot); ?>

        </main>

        
        <footer class="border-t border-slate-200 bg-white py-3 shrink-0">
            <div class="px-6 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-slate-400">
                <p>&copy; <?php echo e(date('Y')); ?> PT Telkom Indonesia (Persero) Tbk — Evaluasi Kelayakan AKI/CAPEX</p>
                <p class="text-[11px]">Production Standard Environment</p>
            </div>
        </footer>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        if (window.lucide) lucide.createIcons();
    });
</script>

<?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\Users\AND\Downloads\Telegram Desktop\project website automation\SIpka\aki-web\resources\views/components/layouts/app.blade.php ENDPATH**/ ?>