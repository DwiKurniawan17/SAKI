<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['class' => 'h-9']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['class' => 'h-9']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div <?php echo e($attributes->merge(['class' => 'inline-flex items-center gap-2.5 ' . $class])); ?>>
    <div class="relative w-9 h-9 bg-gradient-to-tr from-red-700 via-red-600 to-red-500 rounded-xl shadow-sm flex items-center justify-center text-white ring-2 ring-red-100">
        
        <svg class="w-5 h-5 text-white drop-shadow-sm" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
            <path stroke-linecap="round" stroke-linejoin="round" d="M13 10V3L4 14h7v7l9-11h-7z" />
        </svg>
    </div>
    <div class="flex flex-col text-left leading-none">
        <span class="text-base font-black tracking-tight text-slate-900">
            Telkom<span class="text-red-600">Indonesia</span>
        </span>
        <span class="text-[10px] font-semibold tracking-wider uppercase text-slate-400 mt-0.5">
            AKI / CAPEX Engine
        </span>
    </div>
</div>

<?php /**PATH C:\Users\AND\Downloads\Telegram Desktop\project website automation\SIpka\aki-web\resources\views/components/logo.blade.php ENDPATH**/ ?>