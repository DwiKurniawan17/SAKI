<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => 'Laporan Simulasi']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Laporan Simulasi']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <div class="space-y-6">
        
        <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-200 pb-5">
            <div>
                <h1 class="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">Laporan Simulasi AKI/CAPEX</h1>
                <p class="text-sm text-slate-500 mt-1">Kelola dan cetak laporan agregat dari seluruh data simulasi investasi.</p>
            </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->user()->hasRole('admin')): ?>
            <a href="<?php echo e(route('laporan.create')); ?>"
               class="inline-flex items-center justify-center gap-2 bg-red-600 hover:bg-red-700 text-white text-xs font-semibold px-4 h-10 rounded-lg transition-colors shadow-sm">
                <i data-lucide="plus" class="w-4 h-4"></i>
                <span>Buat Laporan Baru</span>
            </a>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>

        
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('status')): ?>
        <div class="bg-emerald-50 border border-emerald-200 rounded-xl px-4 py-3 flex items-center gap-3 text-emerald-800 text-sm">
            <i data-lucide="check-circle-2" class="w-4 h-4 text-emerald-600 shrink-0"></i>
            <span><?php echo e(session('status')); ?></span>
        </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('error')): ?>
        <div class="bg-rose-50 border border-rose-200 rounded-xl px-4 py-3 flex items-center gap-3 text-rose-800 text-sm">
            <i data-lucide="alert-circle" class="w-4 h-4 text-rose-600 shrink-0"></i>
            <span><?php echo e(session('error')); ?></span>
        </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        
        <form method="GET" action="<?php echo e(route('laporan.index')); ?>" class="bg-white rounded-xl border border-slate-200 p-4 shadow-sm">
            <div class="flex flex-col sm:flex-row gap-3">
                <div class="flex-1 relative">
                    <div class="absolute inset-y-0 left-3 flex items-center pointer-events-none text-slate-400">
                        <i data-lucide="search" class="w-4 h-4"></i>
                    </div>
                    <input type="text" name="q" value="<?php echo e(request('q')); ?>" placeholder="Cari judul laporan..."
                           class="w-full h-10 rounded-lg border border-slate-300 pl-9 pr-4 text-sm text-slate-900 placeholder-slate-400 focus:border-red-600 focus:ring-1 focus:ring-red-600 outline-none transition">
                </div>
                <select name="status" class="h-10 rounded-lg border border-slate-300 px-3 text-xs text-slate-700 focus:border-red-600 focus:ring-1 focus:ring-red-600 outline-none bg-white min-w-[160px]">
                    <option value="">Semua Status</option>
                    <option value="draft" <?php echo e(request('status') === 'draft' ? 'selected' : ''); ?>>Draft</option>
                    <option value="final" <?php echo e(request('status') === 'final' ? 'selected' : ''); ?>>Final</option>
                </select>
                <button type="submit"
                        class="inline-flex items-center justify-center gap-2 bg-slate-900 hover:bg-slate-800 text-white font-medium px-5 h-10 rounded-lg text-xs transition-colors shadow-sm">
                    <i data-lucide="search" class="w-3.5 h-3.5"></i>
                    <span>Cari</span>
                </button>
            </div>
        </form>

        
        <div class="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(count($laporans) > 0): ?>
            <div class="overflow-x-auto">
                <table class="w-full text-left text-xs">
                    <thead>
                        <tr class="bg-slate-50 border-b border-slate-200 text-slate-600">
                            <th class="px-6 py-3 font-semibold uppercase tracking-wider text-[11px]">Judul Laporan</th>
                            <th class="px-6 py-3 font-semibold uppercase tracking-wider text-[11px]">Periode</th>
                            <th class="px-6 py-3 font-semibold uppercase tracking-wider text-[11px]">Statistik</th>
                            <th class="px-6 py-3 font-semibold uppercase tracking-wider text-[11px]">Status</th>
                            <th class="px-6 py-3 font-semibold uppercase tracking-wider text-[11px]">Dibuat Oleh</th>
                            <th class="px-6 py-3 font-semibold uppercase tracking-wider text-[11px] text-right">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $laporans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <tr class="hover:bg-slate-50/70 transition-colors">
                            <td class="px-6 py-3.5">
                                <div class="flex items-start gap-2.5">
                                    <div class="w-8 h-8 rounded-lg bg-red-50 flex items-center justify-center text-red-500 shrink-0 mt-0.5 border border-red-100">
                                        <i data-lucide="file-bar-chart" class="w-4 h-4"></i>
                                    </div>
                                    <div>
                                        <a href="<?php echo e(route('laporan.show', $item)); ?>"
                                           class="font-semibold text-slate-900 hover:text-red-600 transition-colors">
                                            <?php echo e($item->judul); ?>

                                        </a>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($item->deskripsi): ?>
                                        <p class="text-[11px] text-slate-400 mt-0.5 line-clamp-1"><?php echo e($item->deskripsi); ?></p>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        <span class="inline-flex items-center gap-1 text-[11px] text-slate-400 mt-0.5">
                                            <i data-lucide="clock" class="w-3 h-3"></i>
                                            <?php echo e($item->created_at->translatedFormat('d M Y')); ?>

                                        </span>
                                    </div>
                                </div>
                            </td>
                            <td class="px-6 py-3.5 text-slate-600">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($item->periode_mulai || $item->periode_akhir): ?>
                                <div class="text-xs space-y-0.5">
                                    <div><span class="text-slate-400 text-[10px]">Dari</span> <?php echo e($item->periode_mulai?->format('d M Y') ?? '—'); ?></div>
                                    <div><span class="text-slate-400 text-[10px]">s/d</span> <?php echo e($item->periode_akhir?->format('d M Y') ?? '—'); ?></div>
                                </div>
                                <?php else: ?>
                                <span class="text-slate-400 font-mono">— Semua —</span>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </td>
                            <td class="px-6 py-3.5">
                                <div class="flex flex-col gap-0.5">
                                    <span class="text-[11px] font-semibold text-slate-700"><?php echo e($item->total_simulasi); ?> simulasi</span>
                                    <div class="flex items-center gap-1.5 flex-wrap">
                                        <span class="inline-flex items-center gap-0.5 text-[11px] text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-100">
                                            <i data-lucide="check" class="w-2.5 h-2.5"></i><?php echo e($item->total_layak); ?> Layak
                                        </span>
                                        <span class="inline-flex items-center gap-0.5 text-[11px] text-rose-700 bg-rose-50 px-1.5 py-0.5 rounded border border-rose-100">
                                            <i data-lucide="x" class="w-2.5 h-2.5"></i><?php echo e($item->total_tidak_layak); ?> Tdk Layak
                                        </span>
                                    </div>
                                </div>
                            </td>
                            <td class="px-6 py-3.5">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($item->status === 'final'): ?>
                                <span class="bg-emerald-50 text-emerald-700 border border-emerald-200 px-2.5 py-0.5 rounded-md inline-flex items-center gap-1 font-bold text-[11px]">
                                    <i data-lucide="badge-check" class="w-3 h-3"></i> Final
                                </span>
                                <?php else: ?>
                                <span class="bg-amber-50 text-amber-700 border border-amber-200 px-2.5 py-0.5 rounded-md inline-flex items-center gap-1 font-semibold text-[11px]">
                                    <i data-lucide="pencil" class="w-3 h-3"></i> Draft
                                </span>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </td>
                            <td class="px-6 py-3.5 text-slate-600 text-xs">
                                <?php echo e($item->creator?->name ?? '—'); ?>

                            </td>
                            <td class="px-6 py-3.5 text-right">
                                <div class="flex items-center justify-end gap-3">
                                    <a href="<?php echo e(route('laporan.show', $item)); ?>"
                                       class="text-red-600 hover:text-red-700 font-semibold text-xs transition-colors inline-flex items-center gap-0.5">
                                        <span>Detail</span>
                                        <i data-lucide="arrow-right" class="w-3.5 h-3.5"></i>
                                    </a>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->user()->hasRole('admin') && $item->status !== 'final'): ?>
                                    <a href="<?php echo e(route('laporan.edit', $item)); ?>"
                                       class="text-slate-500 hover:text-slate-700 font-semibold text-xs transition-colors inline-flex items-center gap-0.5">
                                        <i data-lucide="edit-3" class="w-3.5 h-3.5"></i>
                                        <span>Edit</span>
                                    </a>
                                    <form method="POST" action="<?php echo e(route('laporan.destroy', $item)); ?>"
                                          onsubmit="return confirm('Hapus laporan ini?')" class="inline">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button type="submit"
                                                class="text-rose-500 hover:text-rose-700 font-semibold text-xs transition-colors inline-flex items-center gap-0.5 cursor-pointer">
                                            <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
                                            <span>Hapus</span>
                                        </button>
                                    </form>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="px-6 py-4 border-t border-slate-100 bg-slate-50/50">
                <?php echo e($laporans->links()); ?>

            </div>
            <?php else: ?>
            <div class="p-12 text-center text-slate-400 text-sm flex flex-col items-center">
                <div class="w-12 h-12 bg-slate-100 rounded-xl flex items-center justify-center text-slate-400 mb-3 border border-slate-200">
                    <i data-lucide="file-bar-chart" class="w-6 h-6"></i>
                </div>
                <p class="font-medium text-slate-600">Belum ada laporan simulasi.</p>
                <p class="text-xs text-slate-400 mt-1">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->user()->hasRole('admin')): ?>
                        Klik tombol "Buat Laporan Baru" untuk membuat laporan pertama.
                    <?php else: ?>
                        Laporan simulasi akan tersedia setelah RSO membuatnya.
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </p>
            </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH C:\Users\AND\Downloads\Telegram Desktop\project website automation\SIpka\aki-web\resources\views/laporan/index.blade.php ENDPATH**/ ?>